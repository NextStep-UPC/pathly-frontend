export const loginForm = {
  email: '',
  password: '',
};