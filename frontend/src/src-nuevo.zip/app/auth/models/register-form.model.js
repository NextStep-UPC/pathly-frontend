export const registerForm = {
    name: '',
    lastname: '',
    birthdate: '',
    phone: '',
    email: '',
    password: '',
    confirmPassword: '',
    // role: 'Normal'
};