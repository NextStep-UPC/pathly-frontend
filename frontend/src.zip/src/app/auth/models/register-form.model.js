export const registerForm = {
    name:            '',
    lastname:        '',
    birthdate:       '',
    phone:           '',
    email:           '',
    password:        '',
    confirmPassword: ''
};