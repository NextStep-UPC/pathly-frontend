export const ROLES = {
  ADMIN: 'admin',
  STUDENT: 'student',
  PSYCHOLOGIST: 'psychologist'
};